#from flask import Flask,render_template
#app = Flask(__name__) #name is a special variable in python, it holds the name of the current module

#@ means decorator, it is used to modify the behavior of a function
#@app.route('/home',methods=['GET']) #route() is a decorator, it is used to bind a function to a URL
#def home():
 #   return "This the first route"

#create another route /about
#@app.route('/about',methods=['GET'])
#def about():
 #   return "This is the about route"

#@app.route('/index')
#def index_html():
#    return render_template('index.html') #render_template is used to render html files

#app.run(use_reloader=True) #debug=True -> to enable debug mode

import requests
import os
from dotenv import load_dotenv
from flask import Flask, render_template

load_dotenv()

API_KEY = os.getenv("api_key")

if not API_KEY:
    raise ValueError("API key not found. Check your .env file.")

API_URL = "https://api.api-ninjas.com/v1/quotes"

headers = {
    "X-Api-Key": API_KEY
}

app = Flask(__name__)

def generate_ai_quote():
    response = requests.get(API_URL, headers=headers)
    data = response.json()

    if isinstance(data, list) and len(data) > 0:
        quote = data[0]["quote"]
        author = data[0]["author"]
        return quote, author
    else:
        return "No quote received", "Unknown"

@app.route("/")
def home():
    quote, author = generate_ai_quote()
    return render_template(
        "index.html",
        quote=quote,
        author=author
    )

if __name__ == "__main__":
    app.run(debug=True)