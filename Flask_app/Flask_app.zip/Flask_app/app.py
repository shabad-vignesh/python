from flask import Flask
app = Flask(__name__) #name is a special variable in python, it holds the name of the current module

#@ means decorator, it is used to modify the behavior of a function
@app.route('/home',methods=['GET']) #route() is a decorator, it is used to bind a function to a URL
def home():
    return "This the first route"

#create another route /about
@app.route('/about',methods=['GET'])
def about():
    return "This is the about route"

app.run(use_reloader=True) #debug=True -> to enable debug mode