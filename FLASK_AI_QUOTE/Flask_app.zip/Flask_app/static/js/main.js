document.addEventListener('DOMContentLoaded', () => {
  const box = document.querySelector('.box');
  if (box) box.classList.add('visible');

  const form = document.querySelector('form');
  const btn = document.getElementById('generate-btn');
  const quoteEl = document.querySelector('.quote');
  const authorEl = document.querySelector('.author');

  // Move focus to quote for screen readers when new page loads
  if (quoteEl) {
    quoteEl.setAttribute('tabindex', '-1');
  }

  if (form && btn) {
    form.addEventListener('submit', () => {
      // show spinner and disable button to prevent double submit
      btn.disabled = true;
      const spinner = btn.querySelector('.spinner');
      const text = btn.querySelector('.btn-text');
      if (spinner) spinner.style.display = 'inline-block';
      if (text) text.textContent = 'Generating...';
    });
  }

  // after a brief delay set focus to quote so assistive tech reads it
  setTimeout(() => {
    if (quoteEl) quoteEl.focus({preventScroll: true});
  }, 300);
});

